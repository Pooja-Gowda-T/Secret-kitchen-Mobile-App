package com.example.a777;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class menu extends AppCompatActivity {
    Button btn,btn1,btn2,btn3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_menu);
        btn=(Button) findViewById(R.id.btn);
        btn1=(Button) findViewById(R.id.btn1);
        btn2=(Button) findViewById(R.id.btn2);
        btn3=(Button) findViewById(R.id.btn3);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(menu.this,indian.class);startActivity(intent);
                Toast.makeText(menu.this, "Get ready to order!!", Toast.LENGTH_SHORT).show();
            }
        });
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {
                Intent intent=new Intent(menu.this,fastfood.class);startActivity(intent);
                Toast.makeText(menu.this, "Get ready to order!! ", Toast.LENGTH_SHORT).show();
            }
        });btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               Intent intent=new Intent(menu.this,recepies.class);startActivity(intent);
                Toast.makeText(menu.this, "Get ready to Explore!! ", Toast.LENGTH_SHORT).show();

            }
        });btn3.setOnClickListener(new View.OnClickListener() {
            @Override
           public void onClick(View view) {
                Intent intent=new Intent(menu.this,review.class);startActivity(intent);
                Toast.makeText(menu.this, "I hope u enjoyed!! ", Toast.LENGTH_SHORT).show();

            }
       });
    }
}














