package com.example.a777;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;

public class recepies extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recepies);
    getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
}
public void web(View view)
{
    openUrl("https://www.bing.com/search?q=recipe+for+chicken+samosa+&form=ANSPH1&refig=b466b13e6f184408974966339f53f919&sp=-1&ghc=2&pq=recipe+for+chicken+samosa+&sc=1-26&qs=n&sk=&cvid=b466b13e6f184408974966339f53f919");

}
public void openUrl(String url)
{
    Uri uri=Uri.parse(url);
    Intent launchWeb=new Intent(Intent.ACTION_VIEW,uri);
    startActivity(launchWeb);
}
    public void web1(View view)
    {
        openUrl1("https://www.bing.com/search?q=recipe+for+gobi+manchurian&qs=AS&pq=recipe+for+gobi&sk=AS2&sc=4-15&cvid=989EFE41C3004F519E0F50CD9613AC5B&FORM=QBRE&sp=3");
    }
    public void openUrl1(String url)
    {
        Uri uri=Uri.parse(url);
        Intent launchWeb=new Intent(Intent.ACTION_VIEW,uri);
        startActivity(launchWeb);
    }
    public void web2(View view)
    {
        openUrl3("https://www.bing.com/search?q=recipe+for+pani+puri&qs=AS&pq=recipe+for+pani&sc=7-15&cvid=201D33225757404F8652064790C3EBA3&FORM=QBRE&sp=1");
    }
    public void openUrl3(String url1)
    {
        Uri uri=Uri.parse(url1);
        Intent launchWeb=new Intent(Intent.ACTION_VIEW,uri);
        startActivity(launchWeb);
    }
    public void web3(View view)
    {
        openUrl4("https://www.bing.com/search?q=recipe+for+pani+puri&qs=AS&pq=recipe+for+pani&sc=7-15&cvid=201D33225757404F8652064790C3EBA3&FORM=QBRE&sp=1");
    }
    public void openUrl4(String url2)
    {
        Uri uri=Uri.parse(url2);
        Intent launchWeb=new Intent(Intent.ACTION_VIEW,uri);
        startActivity(launchWeb);
    }


}