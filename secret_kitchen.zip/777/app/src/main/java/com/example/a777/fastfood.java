package com.example.a777;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Toast;

public class fastfood extends AppCompatActivity {
    Button btn1,btn2,btn3,btn4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fastfood);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        btn1=(Button)findViewById(R.id.btn1);
        btn2=(Button)findViewById(R.id.btn2);
        btn3=(Button)findViewById(R.id.btn3);
        btn4=(Button)findViewById(R.id.btn4);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(fastfood.this,burger.class);startActivity(intent);

                Toast.makeText(fastfood.this, "THANK U FOR ORDERING!!", Toast.LENGTH_SHORT).show();
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {
                Intent intent=new Intent(fastfood.this,fries.class);startActivity(intent);

                Toast.makeText(fastfood.this, "THANK U FOR ORDERING!!", Toast.LENGTH_SHORT).show();
            }
        });btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(fastfood.this,pizza.class);startActivity(intent);
                Toast.makeText(fastfood.this, "THANK U FOR ORDERING!!", Toast.LENGTH_SHORT).show();

            }
        });btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(fastfood.this,cupcake.class);startActivity(intent);
                Toast.makeText(fastfood.this, "THANK U FOR ORDERING!!", Toast.LENGTH_SHORT).show();

            }
        });

    }
}